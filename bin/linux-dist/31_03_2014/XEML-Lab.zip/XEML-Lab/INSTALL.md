#XEML-Lab 1.0


##Prerequisites 
=========
###compilation :

To Compile the source, you need to install:

* Framework Qt 4.8 or higher (for developers, Package framework + Qt creator are available for differents OS [here](http://qt-project.org/downloads))

* libstdc++6 and C++ Compiler (g++, gcc MinGW) related to your operating system.

###platform :

Mac OS 10.5 or higher:

Windows (xp or higher):

Linux ()




