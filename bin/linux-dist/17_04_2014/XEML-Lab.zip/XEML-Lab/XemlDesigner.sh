#!/bin/sh

DIR=$(dirname $0)

export LD_LIBRARY_PATH=$DIR/Qt_Libraries
export QT_QPA_PLATFORM_PLUGIN_PATH=$DIR/plugins/platforms

$DIR/XemlDesigner
